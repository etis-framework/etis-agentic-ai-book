import sys,os,zipfile,math
from pathlib import Path
sys.path.insert(0,'/mnt/data/etis_figure_pilot')
import svgwrite,cairosvg
from docx import Document
from docx.shared import Inches,Pt
from docx.enum.section import WD_ORIENT
P=Path('/mnt/data/etis_g1_approved'); W,H=1440,830
NAVY='#19344E'; BLUE='#DCEAF5'; TEAL='#DDF1EC'; AMBER='#FFF0D2'; GRAY='#EFF2F5'; LAV='#E8E5F1'; INK=NAVY; MUTED='#4B6070'; LINE='#60798A'; WHITE='#FFFFFF'; RED='#A44743'
def init(title,sub):
 d=svgwrite.Drawing(size=(f'{W}px',f'{H}px'),viewBox=f'0 0 {W} {H}');d.add(d.rect(insert=(0,0),size=(W,H),fill=WHITE));label(d,50,52,title,27,NAVY,True);label(d,50,85,sub,17,MUTED);return d
def label(d,x,y,s,fs=18,color=INK,bold=False,anchor=None):
 kw=dict(insert=(x,y),font_family='DejaVu Sans',font_size=fs,fill=color,font_weight='bold' if bold else 'normal')
 if anchor:kw['text_anchor']=anchor
 d.add(d.text(s,**kw))
def box(d,x,y,w,h,title,lines=(),fill=BLUE,fs=19):
 d.add(d.rect(insert=(x,y),size=(w,h),rx=10,fill=fill,stroke=LINE,stroke_width=2));label(d,x+17,y+34,title,fs,NAVY,True)
 for j,s in enumerate(lines):label(d,x+17,y+65+j*26,s,17)
def panel(d,x,y,w,h,title,fill='#F8FAFC'):
 d.add(d.rect(insert=(x,y),size=(w,h),rx=14,fill=fill,stroke='#8297A8',stroke_width=2));d.add(d.rect(insert=(x,y),size=(w,42),rx=9,fill=NAVY));label(d,x+17,y+28,title,17,WHITE,True)
def arrow(d,pts,color=LINE,dash=False):
 kw=dict(points=pts,stroke=color,stroke_width=2.8,fill='none');
 if dash:kw['stroke_dasharray']='8,6'
 d.add(d.polyline(**kw));a,b=pts[-2:];ang=math.atan2(b[1]-a[1],b[0]-a[0]);s=11;d.add(d.polygon([b,(b[0]-s*math.cos(ang-.5),b[1]-s*math.sin(ang-.5)),(b[0]-s*math.cos(ang+.5),b[1]-s*math.sin(ang+.5))],fill=color))
def save(d,id):
 d.saveas(str(P/(id+'.svg')));cairosvg.svg2png(url=str(P/(id+'.svg')),write_to=str(P/(id+'.png')),output_width=2160,output_height=1245)
# Architecture figures: nested subsystem panels with peer components, not workflow chains.
arch={
'A01':('Enterprise context architecture','Enterprise actors, agentic platform, business systems, and external authority',[
 ('BUSINESS ENGAGEMENT',[('Business owners','Goals · risk appetite'),('Users / reviewers','Approval · exceptions')]),('ENTERPRISE AGENTIC PLATFORM',[('E1 + E2','Admission · coordination'),('E3 + E4','Reasoning · context'),('E5 + E7','Control · durable state')]),('EXISTING ENTERPRISE',[('E6 + E8','Systems and providers'),('E9','Governance · assurance')])]),
'A02':('E3 agent internal architecture','Anatomy of a bounded agent; internal cognition does not confer business authority',[
 ('INPUT AND OBSERVATION',[('Task contract','Goal · constraints'),('Perception','Normalize · classify')]),('REASONING CAPABILITIES',[('Planning','Options · steps'),('Evaluation','Check · revise'),('Model choice','Rules · SLM · LLM')]),('OUTPUT AND SUPPORT',[('Typed proposal','Evidence · uncertainty'),('E4 context','Retrieval · memory'),('E5 boundary','Independent effect check')])]),
'A04':('Enterprise trust boundaries','Separate identities, untrusted reasoning, effect authority, and business truth',[
 ('B1 · ADMISSION',[('Caller identity','Tenant · principal'),('E1 scope','Goal · data boundary')]),('B2 · REASONING',[('E3 workers','Untrusted proposals'),('E4 sources','Provenance · labels'),('E2 delegation','Bounded task identity')]),('B3 · CONSEQUENCES',[('E5 authority','Policy · approvals'),('E6 credentials','Constrained adapters'),('E8 truth','Business outcomes')])]),
'A05':('E2 coordination architecture','Workflow ownership, registry, dispatch, and durable control are distinct capabilities',[
 ('WORKFLOW CONTROL',[('Admission contract','C01 scope'),('State machine','Durable transitions'),('Owner / epoch','Single logical owner')]),('AGENT MANAGEMENT',[('Approved registry','Versions · permissions'),('Task dispatcher','C02 bounded work'),('Agent workers','E3 runtime instances')]),('RECOVERY AND STATE',[('E7 checkpoint','Journal · outbox'),('Recovery owner','Lease and fencing'),('E9 monitoring','Stalled task alerts')])]),
'A06':('E4 context and knowledge architecture','Retrieval, memory, and authoritative state have different contracts',[
 ('ACCESS AND RETRIEVAL',[('Context gateway','C03 · tenant scope'),('Retrieval engine','Freshness · provenance'),('Source controls','Classification · ACL')]),('CONTEXT RESOURCES',[('Knowledge corpus','Governed documents'),('Agent memory','Working · episodic'),('Evidence links','Citation · version')]),('NOT E4-OWNED',[('E7 operational state','Workflow checkpoints'),('E8 business truth','Customer · refund'),('E9 governance','Retention · privacy')])]),
'A08':('E6 enterprise integration architecture','Adapters isolate protocols and provider behavior from agent reasoning',[
 ('CONTROLLED INGRESS',[('E5 command','Authorized effect'),('Tool gateway','Least privilege'),('Typed adapters','Schemas · timeouts')]),('INTEGRATION SERVICES',[('Idempotency map','Stable operation key'),('Status interface','C08 reconciliation'),('Provider telemetry','Traces · outcomes')]),('ENTERPRISE DEPENDENCIES',[('E8 payment','Refund effect'),('E8 customer','Account lookup'),('External providers','Contract variation')])]),
'A09':('Physical deployment architecture','Logical E-domains may be co-located or distributed; placement follows risk and latency',[
 ('CLOUD / PRIMARY',[('E1 ingress','Auth · routing'),('E2 + E7','Durable coordination'),('E3 + E4','Elastic agent workers')]),('CONTROLLED SERVICE ZONE',[('E5 enforcement','Isolated permissions'),('E6 adapters','Private connectors'),('E9 assurance','Audit · monitoring')]),('EXTERNAL / ON-PREM',[('E8 systems','Customer · finance'),('Provider endpoints','Idempotency · status'),('Recovery region','Failover capacity')])]),
'A10':('Recovery and failure-domain architecture','Separate runtime recovery from uncertain business-effect reconciliation',[
 ('RUNTIME FAILURE DOMAINS',[('Region A','Coordinator · workers'),('Region B','Failover capacity'),('Lease control','Epoch authority')]),('DURABLE CONTROL',[('E7 journal','Intents · outbox'),('Operation ledger','UNKNOWN states'),('Reconciler','Provider status checks')]),('EXTERNAL TRUTH / ASSURANCE',[('E8 provider','Authoritative effects'),('E9 operations','SLO · incident'),('Manual review','Unresolvable outcomes')])]),
'A11':('E9 governance and assurance architecture','Cross-cutting controls and accountable owners across the system lifecycle',[
 ('ACCOUNTABILITY',[('Business owner','Outcomes · autonomy'),('Technical owner','Components · releases'),('Security owner','Policies · exceptions')]),('ASSURANCE CONTROLS',[('Evaluation','Adversarial · regression'),('Release governance','Version · canary'),('Observability','Trace · drift · SLO')]),('OPERATIONS AND EVIDENCE',[('Incident response','Quarantine · restore'),('Evidence store','Audit · approvals'),('Economics','Cost / accepted outcome')])])}
for id,(title,sub,panels) in arch.items():
 d=init(id+' | '+title,sub)
 for j,(pt,items) in enumerate(panels):
  x=45+j*465;panel(d,x,126,445,590,pt)
  for k,(heading,detail) in enumerate(items):box(d,x+23,195+k*155,399,116,heading,[detail],fill=[BLUE,TEAL,AMBER,GRAY][(j+k)%4])
 # relationships shown in dedicated connector gutters between structural domains
 for j in (0,1):
  x=45+j*465+445;arrow(d,[(x,423),(x+20,423)],color=LINE)
 label(d,51,778,'Architectural responsibility view · peer components · interfaces and trust boundaries detailed in CAB-001',17,MUTED)
 save(d,id)
# Decision diagrams: explicit parallel alternatives, criteria and recommendation, not chained boxes.
dec={
'D01':('Deterministic versus agentic selection',[('Deterministic workflow','Stable rules · known inputs','Reproducible · low variance','Prefer for consequential decisions'),('Bounded single agent','Ambiguous text · judgment support','Evaluation and review required','No autonomous financial authority'),('Multiagent coordination','Independent specialized tasks','Higher cost · failure surface','Use only when justified')]),
'D02':('Progressive implementation profiles',[('A / B · Advisory','Bounded reasoning · read-only','Identity · scoped retrieval','No consequential effects'),('C · Trusted effects','E5 policy · approvals · E7 ledger','Stable operation keys','Provider reconciliation'),('D / E · Distributed','E2 durable owner · fencing','Failover · incident response','Complexity justified by SLOs')]),
'D03':('Coordination alternatives',[('Deterministic owner','Explicit workflow state machine','Strongest replay / recovery clarity','Default for regulated effects'),('Reasoning supervisor','Dynamic decomposition','More variable plans / evaluation','Keep E5 independent'),('Peer / choreography','Loose coupling via events','Harder global ownership','Use for low-coupling domains')]),
'D04':('Economics and architecture selection',[('Deterministic baseline','Low model spend','Limited ambiguous work','Measure completed outcomes'),('Single bounded agent','Inference + review costs','Potential productivity benefit','Measure error and escalation'),('Multiagent platform','Higher orchestration overhead','More recovery complexity','Justify incremental value')])}
for id,(title,options) in dec.items():
 d=init(id+' | '+title,'Engineering decision view · alternatives are compared, not steps in a workflow')
 for j,(head,a,b,c) in enumerate(options):
  x=48+j*466;panel(d,x,133,440,555,'OPTION '+str(j+1))
  box(d,x+18,198,404,111,head,[a],fill=[BLUE,TEAL,AMBER][j])
  box(d,x+18,340,404,113,'Tradeoff',[b],fill=GRAY)
  box(d,x+18,483,404,113,'Selection guidance',[c],fill=GRAY)
 label(d,53,763,'Selection rule: choose the least complex architecture that meets business correctness, authority, and recovery requirements.',17,RED)
 save(d,id)
# Behavioral diagrams: swimlane sequence with horizontal time and numbered events.
beh={
'B01':('Bounded reason–act interaction',['E1 admitted task','E3 reasoning','E4 context','E6 read tool','E3 evaluator'],['Admit scoped task','Request bounded context','Retrieve cited evidence','Call read-only tool','Observe and evaluate','Return typed advice']),
'B02':('Trusted refund execution',['E3 agent','E5 authority','E7 ledger','E6 adapter','E8 provider'],['Propose $500 refund','Verify scope and policy','Record durable intent K','Dispatch with stable key K','Provider returns outcome','Persist verified result']),
'B03':('Operation ledger state behavior',['E5 command','E7 ledger','E6 adapter','E8 provider','E9 review'],['Record INTENT','Mark DISPATCHED','Timeout => UNKNOWN','Query authoritative status','CONFIRMED or no-effect','Escalate if unresolved']),
'B04':('Coordinator fencing and failover',['Coordinator A','E7 epoch store','Coordinator B','E5 boundary','E9 monitoring'],['A holds epoch 41','A becomes unreachable','B claims epoch 42','Reject stale A write','Reject stale A effect','B resumes checkpoint']),
'B06':('Prompt-injection containment',['E4 retrieval','E3 agent','E5 authority','E9 security','Human owner'],['Retrieve poisoned content','Label untrusted context','Agent proposes forbidden act','Independent policy denies','Record trace and alert','Quarantine and review']),
'B07':('Assured release lifecycle',['Engineering','Evaluation','Approval','Production','Operations'],['Version complete system','Functional / adversarial tests','Approve scoped release','Canary and observe','Contain threshold breach','Governed change / re-test'])}
for id,(title,actors,steps) in beh.items():
 d=init(id+' | '+title,'Behavioral sequence · time progresses downward · separate from architectural responsibility views')
 xs=[160,435,710,985,1260]
 for j,(x,name) in enumerate(zip(xs,actors)):
  d.add(d.rect(insert=(x-119,135),size=(238,62),rx=8,fill=NAVY));label(d,x,173,name,17,WHITE,True,'middle')
  d.add(d.line(start=(x,197),end=(x,726),stroke='#B0C0CA',stroke_width=2,stroke_dasharray='8,7'))
 for k,step in enumerate(steps):
  y=248+k*79;src=k%4;dst=(src+1)%5
  if k==3:src=4;dst=1
  if k==4:src=1;dst=3
  if k==5:src=3;dst=0
  arrow(d,[(xs[src],y),(xs[dst],y)],color=RED if ('Reject' in step or 'denies' in step or 'UNKNOWN' in step) else LINE)
  mid=(xs[src]+xs[dst])/2
  d.add(d.rect(insert=(mid-119,y-30),size=(238,26),fill=WHITE))
  label(d,mid,y-11,f'{k+1}. {step}',16,RED if ('Reject' in step or 'denies' in step or 'UNKNOWN' in step) else NAVY,False,'middle')
 label(d,53,786,'Behavioral view only: authoritative decisions, durable effects, and recovery remain governed by E5 / E7 / E8.',17,MUTED)
 save(d,id)
# approved 3 masters copied unchanged
import shutil
for id,name in [('A03','A03_target_state'),('A07','A07_trusted_execution'),('B05','B05_lost_ack_sequence')]:
 for ext in ['svg','png']:shutil.copy2('/mnt/data/etis_figure_pilot/'+name+'.'+ext,P/(id+'.'+ext))
all_ids=['A01','A02','D01','A03','A04','A05','A06','A07','A08','D02','D03','B01','B02','B03','B04','A09','A10','B05','B06','A11','B07','D04']
assert all((P/(id+'.svg')).exists() for id in all_ids)
# register DOCX landscape one figure per page
D=Document();sec=D.sections[0];sec.orientation=WD_ORIENT.LANDSCAPE;sec.page_width=Inches(11.7);sec.page_height=Inches(8.3);sec.left_margin=Inches(.5);sec.right_margin=Inches(.5);sec.top_margin=Inches(.48);sec.bottom_margin=Inches(.48)
D.styles['Normal'].font.name='Aptos';D.styles['Normal'].font.size=Pt(10)
D.add_heading('ETIS CAB-001 | G1 Figure Family — Revised',0)
D.add_paragraph('Architecture-led figure set · 22 editable SVG masters · approved three-figure pilot retained unchanged · 10 November 2026')
D.add_heading('Controlled visual system',1)
for s in ['11 architectural figures use nested subsystem components, peer responsibilities, and domain boundaries; they are not workflows.','Seven behavioral figures use sequence/lifeline conventions; four decision figures compare alternatives and tradeoffs.','Consistent DejaVu Sans, navy structure, blue coordination, teal reasoning/context, amber authority, gray integration/state, lavender assurance.','CAB-001 E1–E9 vocabulary preserved; the A03 enterprise target state and A07 trusted execution architecture remain the approved pilot masters.','Review candidate: architecture edge semantics and real print-size readability require user acceptance before full manuscript integration.']:
 D.add_paragraph(s,style='List Bullet')
D.add_heading('Figure inventory',1)
for id in all_ids:D.add_paragraph(id+' — '+('Architecture' if id.startswith('A') else 'Behavior' if id.startswith('B') else 'Decision'),style='List Bullet')
for id in all_ids:
 D.add_page_break();D.add_heading(id+' | '+('Architecture' if id.startswith('A') else 'Behavior' if id.startswith('B') else 'Decision')+' figure',2)
 D.add_picture(str(P/(id+'.png')),width=Inches(10.5))
 D.add_paragraph('CAB-001 traceability: '+id+' · source SVG included · review at final page size.',style='Caption')
out='/mnt/data/ETIS_CAB001_G1_Rebuilt_Figure_Register.docx';D.save(out)
with zipfile.ZipFile('/mnt/data/ETIS_CAB001_G1_Rebuilt_Figure_Masters.zip','w',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(P.iterdir()):
  if file.suffix in ('.svg','.png','.py'):z.write(file,'figures/'+file.name)
print('BUILT',len(all_ids),out)
