import svgwrite, cairosvg, os, zipfile
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
P='/mnt/data/etis_figure_pilot'; W,H=1440,830
NAVY='#19344E'; BLUE='#DCEAF5'; TEAL='#DDF1EC'; AMBER='#FFF0D2'; GRAY='#EFF2F5'; INK='#19344E'; MUTED='#4B6070'; LINE='#60798A'; WHITE='#FFFFFF'; RED='#A44743'
def init(title,subtitle):
 d=svgwrite.Drawing(size=(f'{W}px',f'{H}px'),viewBox=f'0 0 {W} {H}')
 d.add(d.rect(insert=(0,0),size=(W,H),fill=WHITE))
 d.add(d.text(title,insert=(56,55),font_family='DejaVu Sans',font_size=29,font_weight='bold',fill=NAVY))
 d.add(d.text(subtitle,insert=(56,88),font_family='DejaVu Sans',font_size=18,fill=MUTED))
 return d
def box(d,x,y,w,h,heading,lines=(),fill=BLUE,stroke=NAVY,fs=19):
 d.add(d.rect(insert=(x,y),size=(w,h),rx=11,ry=11,fill=fill,stroke=stroke,stroke_width=2))
 d.add(d.text(heading,insert=(x+18,y+32),font_family='DejaVu Sans',font_size=fs,font_weight='bold',fill=INK))
 for i,line in enumerate(lines):d.add(d.text(line,insert=(x+18,y+62+i*25),font_family='DejaVu Sans',font_size=17,fill=INK))
def line(d,pts,color=LINE,arrow=False,dash=False):
 kwargs={'stroke':color,'stroke_width':2.8,'fill':'none'}
 if dash:kwargs['stroke_dasharray']='9,6'
 d.add(d.polyline(points=pts,**kwargs))
 if arrow:
  a,b=pts[-2:]; import math
  ang=math.atan2(b[1]-a[1],b[0]-a[0]); s=11
  q=[b,(b[0]-s*math.cos(ang-.5),b[1]-s*math.sin(ang-.5)),(b[0]-s*math.cos(ang+.5),b[1]-s*math.sin(ang+.5))]
  d.add(d.polygon(q,fill=color))
def label(d,x,y,s,fs=16,color=MUTED):d.add(d.text(s,insert=(x,y),font_family='DejaVu Sans',font_size=fs,fill=color))
def save(d,name):
 d.saveas(f'{P}/{name}.svg');cairosvg.svg2png(url=f'{P}/{name}.svg',write_to=f'{P}/{name}.png',output_width=2160,output_height=1245)
# Architecture: nonsequential nested domain blocks; lines in gutters only.
d=init('A03 | Enterprise target-state reference architecture','CAB-001 canonical logical domains • structural relationships, not an execution sequence')
# column group header strips
for x,w,t in [(48,390,'BUSINESS AND CONTROL'),(455,530,'INTELLIGENCE AND EXECUTION'),(1002,390,'ENTERPRISE AND TRUTH')]:
 d.add(d.rect(insert=(x,120),size=(w,39),fill=NAVY,rx=6));label(d,x+15,147,t,17,WHITE)
box(d,52,177,382,122,'E1  Engagement and admission',['Identity · tenant · goal · risk','Bounded workflow contract'],BLUE)
box(d,52,325,382,122,'E2  Coordination and control',['Durable workflow · registry','Work orders · ownership'],BLUE)
box(d,459,177,522,122,'E3  Agent reasoning',['Perceive · plan · evaluate · propose','Rules, SLMs, LLMs, or hybrid'],TEAL)
box(d,459,325,522,122,'E4  Context and knowledge',['Scoped retrieval · provenance · memory','Context is not authoritative state'],TEAL)
box(d,459,479,522,140,'E5  Trusted execution',['Independent policy / approval checks','Business preconditions · operation identity','Authorized effects only'],AMBER)
box(d,1006,177,382,122,'E6  Enterprise integration',['Typed adapters · provider protocols','Least-privilege tool access'],GRAY)
box(d,1006,325,382,122,'E7  Durable operational state',['Workflow · epochs · operation ledger','Outbox · checkpoints'],GRAY)
box(d,1006,479,382,140,'E8  Business systems of record',['Customer / payment / refund truth','Authoritative outcome reconciliation'],GRAY)
# interface links only in gutters, avoid boxes
line(d,[(243,299),(243,325)],arrow=True)
line(d,[(434,386),(446,386),(446,237),(459,237)],arrow=True)
line(d,[(720,299),(720,325)],arrow=True)
line(d,[(720,447),(720,479)],arrow=True)
line(d,[(981,548),(994,548),(994,237),(1006,237)],arrow=True)
line(d,[(981,568),(995,568),(995,386),(1006,386)],arrow=True)
line(d,[(1197,299),(1197,325)],arrow=True)
line(d,[(1197,447),(1197,479)],arrow=True)
# E9 crosscut
box(d,52,674,1336,98,'E9  Governance and assurance',['Versioned policy · evaluation · security · telemetry · incident response · ownership · economics'],fill='#E8E5F1',fs=20)
label(d,56,649,'B1 admission',16);label(d,463,649,'B2 authority',16);label(d,1009,649,'B3 external truth',16)
save(d,'A03_target_state')
# E5 zoom nested architecture
d=init('A07 | E5 trusted execution — subsystem architecture','Structural decomposition of E5 • C04–C08 contracts • consequential effects require independent controls')
# boundary container
d.add(d.rect(insert=(46,122),size=(1348,602),rx=16,fill='#FAFBFD',stroke=AMBER,stroke_width=5))
label(d,70,154,'E5 TRUSTED EXECUTION AUTHORITY BOUNDARY',18)
box(d,74,189,376,120,'E5.1 Proposal intake',['Typed request · evidence references','Reject malformed / out-of-scope'],TEAL)
box(d,530,189,380,120,'E5.2 Authorization',['Principal · delegation · tenant','Policy version · risk limits'],AMBER)
box(d,992,189,375,120,'E5.3 Approval verifier',['Human approval where required','Bind approval to operation'],AMBER)
box(d,74,405,376,128,'E5.4 Preconditions',['Customer · eligibility · amount','Read authoritative business facts'],AMBER)
box(d,530,405,380,128,'E5.5 Operation control',['Stable key · unique constraint','Durable intent · epoch fencing'],AMBER)
box(d,992,405,375,128,'E5.6 Effect and evidence',['Constrained provider dispatch','Result · UNKNOWN · audit trail'],AMBER)
# links in interbox gutters
line(d,[(450,248),(530,248)],arrow=True)
line(d,[(910,248),(992,248)],arrow=True)
line(d,[(1179,309),(1179,362),(262,362),(262,405)],arrow=True)
line(d,[(450,469),(530,469)],arrow=True)
line(d,[(910,469),(992,469)],arrow=True)
label(d,84,580,'External dependencies (not E5-owned):',19)
for x,t in [(86,'E9 · policy / assurance'),(530,'E7 · ledger / workflow state'),(996,'E6 / E8 · adapters / business truth')]:
 d.add(d.rect(insert=(x,600),size=(370,70),rx=9,fill=GRAY,stroke=LINE,stroke_width=2));label(d,x+15,643,t,17,INK)
label(d,58,773,'Contract rule: durable intent precedes dispatch; a timeout may mean UNKNOWN, never assumed failure.',19,RED)
save(d,'A07_trusted_execution')
# sequence diagram
D=init('B05 | Lost-acknowledgment refund reconciliation','Behavioral sequence • $500 refund • provider commits, acknowledgment is lost, coordinator crashes')
actors=[('Coordinator',130),('E5 trusted action',370),('E7 ledger',620),('E6 adapter',870),('E8 provider',1120),('Reconciler',1350)]
for name,x in actors:
 width=190 if x<1300 else 165
 D.add(D.rect(insert=(x-width/2,127),size=(width,54),rx=7,fill=NAVY));
 D.add(D.text(name,insert=(x,160),text_anchor='middle',font_family='DejaVu Sans',font_size=17,fill=WHITE,font_weight='bold'))
 line(D,[(x,182),(x,740)],color='#A7B5C0',dash=True)
steps=[(220,130,370,'1  Propose $500 refund'),(275,370,620,'2  Persist intent + stable key'),(330,370,870,'3  Dispatch authorized effect'),(385,870,1120,'4  Provider commits once'),(440,1120,870,'5  ACK lost',True),(495,130,130,'6  Coordinator crashes'),(555,1350,620,'7  Read UNKNOWN operation'),(615,1350,1120,'8  Query by stable key'),(675,1120,1350,'9  Confirm committed'),(725,1350,620,'10  Record reconciled outcome')]
for st in steps:
 y,a,b,s,*rest=st
 if a!=b:line(D,[(a,y),(b,y)],color=RED if rest else LINE,arrow=True,dash=bool(rest))
 else:D.add(D.circle(center=(a,y),r=10,fill=RED))
 mid=(a+b)/2 if a!=b else a+30
 D.add(D.rect(insert=(mid-105,y-26),size=(210,23),fill=WHITE))
 D.add(D.text(s,insert=(mid,y-9),text_anchor='middle',font_family='DejaVu Sans',font_size=15.5,fill=RED if rest else INK))
label(D,62,798,'Safety property: do not blindly re-dispatch an uncertain refund; reconcile against authoritative provider truth.',18,RED)
save(D,'B05_lost_ack_sequence')
# Word review pack
out='/mnt/data/ETIS_CAB001_G1_Visual_Standard_Pilot.docx';doc=Document();sec=doc.sections[0];sec.orientation=WD_ORIENT.LANDSCAPE;sec.page_width=Inches(11.7);sec.page_height=Inches(8.3);sec.left_margin=Inches(.55);sec.right_margin=Inches(.55);sec.top_margin=Inches(.5);sec.bottom_margin=Inches(.5)
style=doc.styles['Normal'];style.font.name='Aptos';style.font.size=Pt(10)
def heading(s):doc.add_heading(s,1)
doc.add_heading('ETIS CAB-001 | Architecture Figure Pilot',0)
doc.add_paragraph('G1 corrective gate · three representative figures · architecture-led visual standard · review candidate, not publication approval')
heading('Design rules and acceptance criteria')
for s in ['Architecture figures use grouped component responsibility views, not step-by-step workflows.','Behavioral figures use explicit timing/sequence semantics. The two visual families are intentionally distinct.','Unified palette: navy = headings/structure; blue = admission/coordination; teal = reasoning/context; amber = authority; gray = enterprise state/integration; lavender = cross-cutting governance.','DejaVu Sans is used consistently. Minimum source type 15.5 px at 1440 px canvas, with final page-fit labels targeted at approximately 10–12 pt.','Connectors are routed in gutters. Stable CAB-001 E1–E9 and C01–C09 naming; logical responsibilities are not prescribed deployment units.','This pilot does not replace the approved CAB-001 baseline. Diagram content and arrow semantics require architectural review before propagation.']:
 doc.add_paragraph(s,style='List Bullet')
for i,(name,caption) in enumerate([('A03_target_state','A03 — canonical E1–E9 parent architecture'),('A07_trusted_execution','A07 — E5 component-level architectural zoom'),('B05_lost_ack_sequence','B05 — behavioral sequence, intentionally distinct from architecture')]):
 doc.add_page_break();heading(caption);doc.add_picture(f'{P}/{name}.png',width=Inches(10.5));doc.add_paragraph('Review: component scope, interfaces, readable text, routing, boundary semantics, and page-fit legibility.')
doc.save(out)
with zipfile.ZipFile('/mnt/data/ETIS_CAB001_G1_Visual_Standard_Pilot_Sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in os.listdir(P):
  if f.endswith(('.svg','.png','.py')):z.write(f'{P}/{f}',f)
print(out)
